package com.todo.todorest.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.todo.todorest.entity.Task;

import java.util.List;

@EnableTransactionManagement
public interface TaskRepository extends CrudRepository<Task, Long> {
    List<Task> findByTodoId(long todoId);
}
