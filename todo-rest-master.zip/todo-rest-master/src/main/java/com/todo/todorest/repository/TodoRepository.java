package com.todo.todorest.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.todo.todorest.entity.Todo;

@EnableTransactionManagement
public interface TodoRepository extends CrudRepository<Todo, Long> {

}
